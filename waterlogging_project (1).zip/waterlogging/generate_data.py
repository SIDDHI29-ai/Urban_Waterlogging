"""Builds data/waterlogging.csv  (SYNTHETIC but physically-motivated).
Replace with real data: keep the same columns (see README) and skip this script."""
import numpy as np, pandas as pd
rng = np.random.default_rng(42)

# locality, elevation_m, slope_deg, dist_water_km, drain_density_km_per_km2, builtup_pct, impervious_pct
L = [
("Minto Bridge",211,0.4,2.1,6.0,92,88),("ITO",212,0.6,0.8,7.5,90,85),("Pul Prahladpur",208,0.5,3.0,4.5,85,78),
("Zakhira Underpass",214,0.5,4.5,5.0,88,82),("Kashmere Gate",213,0.7,0.9,7.0,89,84),("Azadpur",218,0.9,6.0,5.5,84,76),
("Mehrauli",250,3.2,12.0,3.5,55,42),("Dwarka Sec-10",226,0.8,15.0,8.0,78,66),("Rohini Sec-7",224,0.8,9.0,7.8,80,70),
("Lajpat Nagar",216,0.9,5.0,6.5,91,86),("Connaught Place",216,0.5,3.8,9.5,93,90),("Vasant Kunj",245,3.0,13.0,4.0,50,38),
("Okhla",207,0.6,1.2,4.8,86,80),("Burari",211,0.4,2.5,3.2,72,62),("Laxmi Nagar",206,0.4,1.0,4.0,94,90),
("Mayur Vihar",205,0.4,0.8,5.8,87,80),("Narela",215,0.6,7.0,2.8,60,48),("Janakpuri",228,0.9,14.0,8.2,82,72),
("Saket",240,2.0,11.0,6.2,70,60),("Karol Bagh",218,0.7,4.2,7.2,95,92),("Shahdara",207,0.5,1.5,4.2,92,87),
("Najafgarh",220,0.5,16.0,2.5,58,45),("Civil Lines",215,0.8,1.6,8.5,70,60),("Preet Vihar",208,0.5,1.8,6.5,90,84)]
loc = pd.DataFrame(L, columns=["locality","elevation_m","slope_deg","dist_water_km","drain_density","builtup_pct","impervious_pct"])
loc["past_flood_reports"] = (6 + 14*(loc.impervious_pct/100) - 0.15*(loc.elevation_m-200) + rng.normal(0,2,len(loc))).clip(0,25).round()
loc.to_csv("data/localities.csv", index=False)

# rain events: Jun-Sep, 2018-2024; heavier-tailed intensities
rows = []
for year in range(2018, 2025):
    for _ in range(55):
        d = pd.Timestamp(year,6,15) + pd.Timedelta(days=int(rng.integers(0,105)), hours=int(rng.integers(0,24)))
        r1 = rng.gamma(1.4, 9)                      # peak hourly intensity mm/h
        r3 = r1*rng.uniform(1.3,2.4)                # 3-hr cumulative
        r24 = r3*rng.uniform(1.2,3.5)               # 24-hr cumulative
        local = rng.normal(1,0.12,len(loc)).clip(.6,1.5)   # spatial variation of the storm
        for i, a in loc.iterrows():
            a1, a3, a24 = r1*local[i], r3*local[i], r24*local[i]
            cap = 8 + 4.5*a.drain_density                      # drain capacity (mm/3h) grows with drain density
            excess = max(0, a3 - cap)                          # threshold: only overflow causes ponding
            pond = 1 if a.elevation_m < 214 else 0.45          # low-lying areas collect runoff
            z = (0.11*excess*pond*(0.4 + a.impervious_pct/100) + 0.0045*a24*(a.impervious_pct/100)**2*10
                 - 0.30*a.slope_deg - 0.04*a.dist_water_km + 0.06*a.past_flood_reports
                 + (0.35 if (a1 > 35 and a.drain_density < 6) else 0)
                 - 3.0 + rng.normal(0,0.6))
            local_rain = (a1, a3, a24)
            rows.append(dict(date=d, locality=a.locality, rain_1h=round(a1,1), rain_3h=round(a3,1), rain_24h=round(a24,1),
                             waterlogged=int(z>0)))
ev = pd.DataFrame(rows).merge(loc, on="locality").sort_values("date").reset_index(drop=True)
# inject realistic mess: missing values + a few sensor outliers
for c in ["rain_1h","rain_3h","slope_deg"]:
    ev.loc[ev.sample(frac=0.015, random_state=1).index, c] = np.nan
ev.loc[ev.sample(n=15, random_state=2).index, "rain_1h"] *= 6
ev.to_csv("data/waterlogging.csv", index=False)
print(ev.shape, "positive rate: %.1f%%" % (100*ev.waterlogged.mean()))

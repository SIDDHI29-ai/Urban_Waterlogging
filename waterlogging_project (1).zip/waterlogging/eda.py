"""Exploratory data analysis: prints statistics, saves charts + stats.json to the folder in argv[1] (default eda_plots)."""
import sys, os, json, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
out = sys.argv[1] if len(sys.argv) > 1 else "eda_plots"; os.makedirs(out, exist_ok=True)
df = pd.read_csv("data/waterlogging.csv", parse_dates=["date"])
num = ["rain_1h","rain_3h","rain_24h","elevation_m","slope_deg","dist_water_km","drain_density","builtup_pct","impervious_pct","past_flood_reports"]
rate = df.groupby("locality").waterlogged.mean().sort_values(ascending=False)
corr = df[num+["waterlogged"]].corr()["waterlogged"].drop("waterlogged").sort_values(key=abs, ascending=False)
st = dict(rows=len(df), cols=df.shape[1], pos_rate=float(df.waterlogged.mean()), n_flood=int(df.waterlogged.sum()),
  missing={k:int(v) for k,v in df[num].isna().sum().items() if v}, rain1h_over120=int((df.rain_1h>120).sum()),
  dates=[str(df.date.min().date()), str(df.date.max().date())], rate_all={k:round(float(v),3) for k,v in rate.items()},
  mean_by_class=df.groupby("waterlogged")[["rain_1h","rain_3h","rain_24h"]].mean().round(1).to_dict(), corr={k:round(float(v),2) for k,v in corr.items()})
json.dump(st, open(f"{out}/stats.json","w"), indent=1); print(json.dumps(st)[:600])
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
fig, ax = plt.subplots(1,2,figsize=(10,5.2),gridspec_kw={"width_ratios":[1,2.2]}); c = df.waterlogged.value_counts().sort_index()
ax[0].bar(["Not flooded","Flooded"],c.values,color=["#1c6bab","#e63e5c"]); ax[0].set_title("Class balance"); ax[0].set_ylim(0,c.max()*1.2)
for i,v in enumerate(c.values): ax[0].text(i,v+60,f"{v:,}\n({v/len(df):.0%})",ha="center")
r = rate.sort_values(); ax[1].barh(r.index,r.values*100,color=plt.cm.RdYlGn_r(r.values/r.max())); ax[1].set_title("Waterlogging rate by locality (%)")
plt.tight_layout(); plt.savefig(f"{out}/eda1_balance_locality.png",dpi=150); plt.close()
cm = df[num+["waterlogged"]].corr(); fig, ax = plt.subplots(figsize=(8,6.5)); im = ax.imshow(cm,cmap="RdBu_r",vmin=-1,vmax=1)
ax.set_xticks(range(len(cm))); ax.set_xticklabels(cm.columns,rotation=60,ha="right"); ax.set_yticks(range(len(cm))); ax.set_yticklabels(cm.columns)
for i in range(len(cm)):
    for j in range(len(cm)): ax.text(j,i,f"{cm.iloc[i,j]:.1f}",ha="center",va="center",fontsize=7,color="white" if abs(cm.iloc[i,j])>.55 else "black")
plt.colorbar(im,shrink=.8); ax.set_title("Correlation matrix"); plt.tight_layout(); plt.savefig(f"{out}/eda2_correlation.png",dpi=150); plt.close()
fig, ax = plt.subplots(1,3,figsize=(10,3.4))
for a,col,t in zip(ax,["rain_1h","rain_3h","rain_24h"],["Peak hourly (mm/h)","3-hour total (mm)","24-hour total (mm)"]):
    for k,cl,lab in [(0,"#1c6bab","Not flooded"),(1,"#e63e5c","Flooded")]: a.hist(df.loc[(df.waterlogged==k)&(df[col]<120),col].dropna(),bins=40,alpha=.65,color=cl,label=lab)
    a.set_title(t)
ax[0].legend(); plt.tight_layout(); plt.savefig(f"{out}/eda3_rainfall.png",dpi=150); plt.close()

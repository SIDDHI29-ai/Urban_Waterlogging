import numpy as np, pandas as pd
STATIC = ["elevation_m","slope_deg","dist_water_km","drain_density","builtup_pct","impervious_pct","past_flood_reports"]
RAIN = ["rain_1h","rain_3h","rain_24h"]
def add_features(df):
    d = df.copy()
    d["rain_intensity_x_imperv"] = d.rain_3h * d.impervious_pct / 100
    d["low_lying"] = 215 - d.elevation_m
    d["drain_deficit"] = 10 - d.drain_density
    d["antecedent_ratio"] = d.rain_24h / (d.rain_3h + 1)
    return d
FEATURES = RAIN + STATIC + ["rain_intensity_x_imperv","low_lying","drain_deficit","antecedent_ratio"]

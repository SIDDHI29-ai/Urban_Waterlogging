"""Refits the 3 models with the tuned hyper-parameters; saves test probabilities, ROC/PR curves and plots (argv[1] = output folder)."""
import sys, json, os, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score, f1_score, confusion_matrix
from features import add_features, FEATURES
out = sys.argv[1] if len(sys.argv) > 1 else "curves"; os.makedirs(out, exist_ok=True)
df = pd.read_csv("data/waterlogging.csv", parse_dates=["date"]).sort_values("date"); df["rain_1h"] = df.rain_1h.clip(upper=120); df = add_features(df)
cut = df.date.quantile(0.8); tr, te = df[df.date <= cut], df[df.date > cut]; imp = lambda: SimpleImputer(strategy="median")
M = {"Logistic Regression": Pipeline([("i",imp()),("s",StandardScaler()),("clf",LogisticRegression(C=10,class_weight="balanced",max_iter=2000))]),
     "Random Forest": Pipeline([("i",imp()),("clf",RandomForestClassifier(n_estimators=200,max_depth=8,class_weight="balanced",random_state=0,n_jobs=-1))]),
     "Gradient Boosting": Pipeline([("i",imp()),("clf",HistGradientBoostingClassifier(class_weight="balanced",max_iter=300,max_depth=5,learning_rate=0.1,random_state=0))])}
y = te.waterlogged.values; res = {}; P = {}
for n, m in M.items():
    if n=="Random Forest" and os.path.exists("models/best_model.joblib"): m = __import__("joblib").load("models/best_model.joblib")  # use the saved (website) model
    else: m.fit(tr[FEATURES], tr.waterlogged)
    p = m.predict_proba(te[FEATURES])[:,1]; P[n] = p
    res[n] = dict(f1=f1_score(y,p>=.5), roc=roc_auc_score(y,p), ap=average_precision_score(y,p)); print(n, {k:round(v,3) for k,v in res[n].items()}, confusion_matrix(y,p>=.5).tolist())
json.dump(dict(y=y.tolist(), probs={n:[round(float(x),3) for x in p] for n,p in P.items()}), open(f"{out}/test_probs.json","w"), separators=(",",":"))
col = {"Logistic Regression":"#1c6bab","Random Forest":"#12b5a5","Gradient Boosting":"#f2a100"}; plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
fig, ax = plt.subplots(1,2,figsize=(10,4.4))
for n,p in P.items():
    f,t,_ = roc_curve(y,p); ax[0].plot(f,t,color=col[n],lw=2,label=f"{n} (AUC {res[n]['roc']:.3f})")
    pr,rc,_ = precision_recall_curve(y,p); ax[1].plot(rc,pr,color=col[n],lw=2,label=f"{n} (AP {res[n]['ap']:.3f})")
ax[0].plot([0,1],[0,1],"--",color="grey",label="Random guess"); ax[0].set(xlabel="False positive rate",ylabel="True positive rate (recall)",title="ROC curve"); ax[0].legend(loc="lower right",fontsize=8)
ax[1].axhline(y.mean(),ls="--",color="grey",label=f"No-skill ({y.mean():.2f})"); ax[1].set(xlabel="Recall",ylabel="Precision",title="Precision-Recall curve",ylim=(0,1.02)); ax[1].legend(loc="lower left",fontsize=8)
plt.tight_layout(); plt.savefig(f"{out}/roc_pr.png",dpi=150); plt.close()
p = P["Random Forest"]; th = np.linspace(.05,.95,91); a_=[];b_=[];c_=[]
for t in th:
    b=p>=t; tp=(b&(y==1)).sum(); a_.append(tp/max(b.sum(),1)); b_.append(tp/(y==1).sum()); c_.append(f1_score(y,b))
fig, ax = plt.subplots(figsize=(6,3.8)); ax.plot(th,a_,color="#1c6bab",label="Precision"); ax.plot(th,b_,color="#12b5a5",label="Recall"); ax.plot(th,c_,color="#f2a100",label="F1")
ax.axvline(.5,ls="--",color="grey"); ax.set(xlabel="Decision threshold",ylabel="Score",title="Random Forest: effect of the threshold"); ax.legend(); plt.tight_layout(); plt.savefig(f"{out}/threshold.png",dpi=150); plt.close()
fig, ax = plt.subplots(1,3,figsize=(10,3.2))
for a,(n,pp) in zip(ax,P.items()):
    cm = confusion_matrix(y,pp>=.5); a.imshow(cm,cmap="Blues"); a.set_title(n,fontsize=9); a.set_xticks([0,1]); a.set_yticks([0,1]); a.set_xticklabels(["Pred dry","Pred flood"]); a.set_yticklabels(["Actual dry","Actual flood"])
    for i in range(2):
        for j in range(2): a.text(j,i,cm[i,j],ha="center",va="center",color="white" if cm[i,j]>cm.max()/2 else "black",fontsize=13)
plt.tight_layout(); plt.savefig(f"{out}/confusion.png",dpi=150); plt.close()

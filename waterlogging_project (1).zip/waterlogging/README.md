# Urban Waterlogging Prediction (Delhi)
ML project: predict whether a locality gets waterlogged from rainfall, terrain and drainage data.

## Run
    pip install -r requirements.txt
    python generate_data.py     # creates data/waterlogging.csv + data/localities.csv
    python train.py             # trains LogReg, Random Forest, XGBoost -> models/, prints the metrics table
    python app.py               # open http://127.0.0.1:5000

## Pipeline (matches the slides)
1. Data: `data/waterlogging.csv` – one row per (rain event, locality): rain_1h, rain_3h, rain_24h, terrain (elevation, slope, distance to water), urban layout (drain density, built-up %, impervious %), past_flood_reports, `waterlogged` (0/1).
2. Preprocess: median imputation, outlier cap on hourly rain, scaling (for logistic regression).
3. Features: impervious-weighted rain, low-lying index, drain deficit, 24h/3h antecedent ratio.
4. Models: Logistic Regression (baseline), Random Forest, XGBoost; class weights for imbalance; time-based split (train on earlier years, test on later); TimeSeriesSplit CV + grid search.
5. Metrics: precision, recall, F1, ROC-AUC + Random Forest feature importance (shown on the website).

## IMPORTANT: using real data
The bundled data is synthetic (physically motivated: drain-capacity overflow, low-lying pooling, imperviousness). Say so in your report/viva.
To use real data, make a CSV with the same columns and put it at `data/waterlogging.csv`, plus a `data/localities.csv` of static features per locality; skip `generate_data.py`.
Real sources: IMD / Open-Meteo or NASA POWER (rainfall), SRTM or Bhuvan/Copernicus DEM (elevation, slope), OpenStreetMap (drains, water bodies, built-up), Delhi PWD / MCD / Delhi Traffic Police waterlogging complaints (labels).

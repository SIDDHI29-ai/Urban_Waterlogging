"""Trains Logistic Regression (baseline), Random Forest, XGBoost; time-based split; saves best model + metrics."""
import json, joblib, numpy as np, pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from features import add_features, FEATURES
try:
    from xgboost import XGBClassifier; HAS_XGB = True
except ImportError:
    HAS_XGB = False

df = pd.read_csv("data/waterlogging.csv", parse_dates=["date"]).sort_values("date")
# outlier handling: cap hourly rain at physically plausible 120 mm/h
df["rain_1h"] = df.rain_1h.clip(upper=120)
df = add_features(df)
cut = df.date.quantile(0.8)                      # time-based split: train on past, test on future
tr, te = df[df.date <= cut], df[df.date > cut]
Xtr, ytr, Xte, yte = tr[FEATURES], tr.waterlogged, te[FEATURES], te.waterlogged
pos_w = (ytr==0).sum()/(ytr==1).sum()            # class-imbalance handling via weights
print(f"train {len(tr)}  test {len(te)}  positives train {ytr.mean():.1%} test {yte.mean():.1%}")

imp = lambda: SimpleImputer(strategy="median")
if HAS_XGB:
    boost = XGBClassifier(scale_pos_weight=pos_w, eval_metric="logloss", random_state=0)
    grid_b = {"clf__n_estimators":[150,300], "clf__max_depth":[3,5], "clf__learning_rate":[0.05,0.1]}
    boost_name = "XGBoost"
else:
    boost = HistGradientBoostingClassifier(class_weight="balanced", random_state=0)
    grid_b = {"clf__max_iter":[150,300], "clf__max_depth":[3,5], "clf__learning_rate":[0.05,0.1]}
    boost_name = "XGBoost (sklearn gradient-boosting fallback)"

models = {
 "Logistic Regression": (Pipeline([("i",imp()),("s",StandardScaler()),("clf",LogisticRegression(class_weight="balanced",max_iter=2000))]),
                         {"clf__C":[0.1,1,10]}),
 "Random Forest": (Pipeline([("i",imp()),("clf",RandomForestClassifier(class_weight="balanced",random_state=0,n_jobs=-1))]),
                   {"clf__n_estimators":[200,400],"clf__max_depth":[8,14,None]}),
 boost_name: (Pipeline([("i",imp()),("clf",boost)]), grid_b),
}
results, fitted = {}, {}
for name,(pipe,grid) in models.items():
    gs = GridSearchCV(pipe, grid, cv=TimeSeriesSplit(4), scoring="f1", n_jobs=-1).fit(Xtr, ytr)
    m = gs.best_estimator_; p = m.predict_proba(Xte)[:,1]
    best_t = 0.5
    pred = (p>=best_t).astype(int)
    results[name] = dict(precision=precision_score(yte,pred), recall=recall_score(yte,pred), f1=f1_score(yte,pred),
                         roc_auc=roc_auc_score(yte,p), cv_f1=gs.best_score_, best_params=gs.best_params_,
                         confusion=confusion_matrix(yte,pred).tolist())
    fitted[name] = m
    print(f"{name:45s} P={results[name]['precision']:.3f} R={results[name]['recall']:.3f} F1={results[name]['f1']:.3f} AUC={results[name]['roc_auc']:.3f}")

best = max(results, key=lambda k: results[k]["f1"])
rf = fitted["Random Forest"].named_steps["clf"]
imps = sorted(zip(FEATURES, rf.feature_importances_), key=lambda x:-x[1])
joblib.dump(fitted[best], "models/best_model.joblib")
json.dump(dict(results=results, best=best, importance=[dict(feature=f,value=float(v)) for f,v in imps],
               n_train=len(tr), n_test=len(te), train_until=str(cut.date()), xgboost_used=HAS_XGB),
          open("models/metrics.json","w"), indent=2)
print("best:", best)

import json, joblib, pandas as pd
from flask import Flask, jsonify, request, render_template
from features import add_features, FEATURES

app = Flask(__name__)
model = joblib.load("models/best_model.joblib")
metrics = json.load(open("models/metrics.json"))
loc = pd.read_csv("data/localities.csv")

def level(p): return "High" if p >= 0.6 else "Medium" if p >= 0.3 else "Low"

def score(names, r1, r3, r24):
    rows = loc[loc.locality.isin(names)].copy()
    rows["rain_1h"], rows["rain_3h"], rows["rain_24h"] = r1, r3, r24
    p = model.predict_proba(add_features(rows)[FEATURES])[:, 1]
    return [dict(locality=n, probability=round(float(x), 3), risk=level(x)) for n, x in zip(rows.locality, p)]

def parse():
    d = request.get_json(force=True)
    r1, r3, r24 = (float(d[k]) for k in ("rain_1h", "rain_3h", "rain_24h"))
    if not (0 <= r1 <= 150 and r1 <= r3 <= 300 and r3 <= r24 <= 600):
        raise ValueError("Rainfall must satisfy 0 ≤ 1-hr ≤ 3-hr ≤ 24-hr (max 150 / 300 / 600 mm).")
    return d, r1, r3, r24

@app.route("/")
def index(): return render_template("index.html", localities=loc.locality.tolist())

@app.post("/api/predict")
def predict():
    try: d, r1, r3, r24 = parse()
    except (ValueError, KeyError, TypeError) as e: return jsonify(error=str(e)), 400
    r = score([d["locality"]], r1, r3, r24)
    if not r: return jsonify(error="Unknown locality."), 400
    return jsonify(r[0] | dict(static=loc[loc.locality == d["locality"]].iloc[0].drop("locality").to_dict()))

@app.post("/api/ranking")
def ranking():
    try: _, r1, r3, r24 = parse()
    except (ValueError, KeyError, TypeError) as e: return jsonify(error=str(e)), 400
    return jsonify(sorted(score(loc.locality.tolist(), r1, r3, r24), key=lambda x: -x["probability"]))

@app.get("/api/metrics")
def get_metrics(): return jsonify(metrics)

if __name__ == "__main__":
    app.run(debug=True)
